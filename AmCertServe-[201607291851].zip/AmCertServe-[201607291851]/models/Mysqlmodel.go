package models

import (
	"AmCertServe/libs/orm"
)

//	Post []*Post  `orm:"reverse(many)"` // 设置一对多的反向关系
//	User *User `orm:"reverse(one)"` // 设置一对一反向关系(可选)
//	User *User  `orm:"rel(fk)"` //设置一对多关系
//	Tags []*Tag `orm:"rel(m2m)"`

//db table t_cus_user
type TCusUser struct {
	Id             string `orm:"size(32);pk"` //primary key, auto increasing
	UserType       string `orm:"size(2)"`
	UserName       string `orm:"size(32)"`
	Password       string `orm:"size(32)"`
	NickName       string `orm:"size(32)"`
	MobilePhone    string `orm:"size(15)"`
	Email          string `orm:"size(32)"`
	CompanyName    string `orm:"size(100)"`
	CompanyAddress string `orm:"size(255)"`
	ForbiddenFlag  string `orm:"size(2)"`
	CreateBy       string `orm:"size(32)"`
	CreateTime     string
	ModifyBy       string `orm:"size(32)"`
	ModifyTime     string
	Remark         string `orm:"size(50)"`
	DelFlag        string `orm:"size(2)"`
}

//db table T_sys_user
type TSysUser struct {
	Id          string `orm:"size(32);pk"` //primary key, auto increasing
	UserName    string `orm:"size(32)"`
	Password    string `orm:"size(32)"`
	MobilePhone string `orm:"size(15)"`
	Email       string `orm:"size(32)"`
	CreateBy    string `orm:"size(32)"`
	CreateTime  string
	ModifyBy    string `orm:"size(32)"`
	ModifyTime  string
	Remark      string `orm:"size(50)"`
	DelFlag     string `orm:"size(2)"`
}

//db table T_sys_role
type TSysRole struct {
	Id          string `orm:"size(32);pk"` //primary key, auto increasing
	RoleName    string `orm:"size(45)"`
	Description string `orm:"size(45)"`
	CreateBy    string `orm:"size(32)"`
	CreateTime  string
	ModifyBy    string `orm:"size(32)"`
	ModifyTime  string
	Remark      string `orm:"size(50)"`
	DelFlag     string `orm:"size(2)"`
}

//db table T_sys_user_role
//type TSysUserRole struct {
//	Id         string
//	UserId     string    `orm:"size(32)"` //*TUser `orm:"rel(fk)"` //OneToMulti relationship
//	RoleId     *TSysRole `orm:"rel(fk)"`
//	CreateBy   string    `orm:"size(32)"`
//	CreateTime string
//	ModifyBy   string `orm:"size(32)"`
//	ModifyTime string
//	Remark     string `orm:"size(50)"`
//	DelFlag    string `orm:"size(2)"`
//}

//db table T_cus_certification
type TCusCertification struct {
	Id           string `orm:"size(32);pk"` //primary key, auto increasing
	CertKey      string `orm:"size(32)"`
	PlatformType string `orm:"size(32)"`
	ProductCode  string `orm:"size(32)"`
	CertType     string `orm:"size(2)"`
	CertStatus   string `orm:"size(2)"`
	CertOwner    int    //bigint
	ApplyCount   int
	UsedCount    int
	StartTime    string
	EndTime      string
	CheckTime    string
	Checker      string `orm:"size(32)"`
	CheckRemark  string `orm:"size(32)"`
	CreateBy     string `orm:"size(32)"`
	CreateTime   string
	ModifyBy     string `orm:"size(32)"`
	ModifyTime   string
	Remark       string `orm:"size(50)"`
	DelFlag      string `orm:"size(2)"`
}

//db table T_cus_certification_binding
type TCusCertificationBinding struct {
	Id          string             `orm:"size(32);pk"` //primary key
	CertId      *TCusCertification `orm:"rel(fk)"`     //OneToMulti relationship
	MachineCode string             `orm:"size(256)"`
	CreateBy    string             `orm:"size(32)"`
	CreateTime  string
	ModifyBy    string `orm:"size(32)"`
	ModifyTime  string
	Remark      string `orm:"size(50)"`
}

func init() {
	// register model
	orm.RegisterModel(new(TCusUser), new(TSysUser) /* new(TSysUserRole),*/, new(TCusCertification), new(TCusCertificationBinding))
	//	orm.RegisterModelWithPrefix("go_", new(Certification)) //注册模型并使用表前缀
	//	orm.RegisterModelWithPrefix("go_", new(Binding))       //注册模型并使用表前缀
}
