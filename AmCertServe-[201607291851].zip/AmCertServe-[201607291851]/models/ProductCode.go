package models

import "strings"

var (
	productCode map[string]string
)

func init() {
	productCode = make(map[string]string)
	productCode["Authen-V0100S"] = "人脸比对1:1"
	productCode["Authen-R0100S"] = "人脸比对1:N"
	productCode["Authen-D0100S"] = "人脸检测"
	productCode["Authen-D0200S"] = "关键点定位"
	productCode["Authen-A0100S"] = "人脸属性分析"
}

func Product_GetNameByCode(codeValue string) string {

	for key, val := range productCode {

		if strings.EqualFold(key, codeValue) {
			return val
		}
	}
	return "未知类型"
}
