package main

import (
	"AmCertServe/serves"
	"log"
	"net/http"
)

func main() {
	//router setting
	http.HandleFunc("/authen/cert/getCerts", serves.AmCertListServe)
	http.HandleFunc("/authen/cert/newlicence", serves.AmCertNewLicenceServe)

	//listen port setting
	err := http.ListenAndServe(":8080", nil)
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
