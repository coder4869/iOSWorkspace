package serves

import (
	"AmCertServe/controllers"
	//	"crypto/md5"
	//	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
)

var (
	amCertCtrl *controllers.AmCertCtrl
	paramError string
)

func init() {
	amCertCtrl = new(controllers.AmCertCtrl)
	paramError = "{\"ErrorNo\":\"1\",\"ErrorInfo\":\"参数错误\",\"Result\":\"null\"}"
}

func AmCertListServe(w http.ResponseWriter, r *http.Request) {
	paramData := BSParseForm(w, r)
	fmt.Println("ParamData=", paramData, "\n")

	amComName := paramData["userName"]
	amPassword := paramData["password"]
	//	if len(amPassword) != 32 {
	//		fmt.Fprintf(w, paramError) //output to client with w
	//		return
	//	}

	//	md5Ctx := md5.New()
	//	md5Ctx.Write([]byte("12345"))
	//	cipherStr := md5Ctx.Sum(nil) //16 bytes
	//	amPsw := hex.EncodeToString(cipherStr)
	//	fmt.Println("cipherStr%v", amPsw)

	respJson := amCertCtrl.AmCertList(amComName, amPassword)
	fmt.Fprintf(w, respJson) //output to client with w
}

func AmCertNewLicenceServe(w http.ResponseWriter, r *http.Request) {
	ParamData := BSParseForm(w, r)
	param := ParamData["param"]
	fmt.Println("param value=", param)

	param = strings.Replace(param, " ", "+", -1) //replace " " with "+"
	fmt.Println("param value=", param)

	//Base64 Decode --> AES Decrypt --> Json
	jsonStr, err := controllers.Base64AesDeResult(param, []byte(controllers.AesKey))
	if err != nil { //param base64&Aes decode failed
		fmt.Println("json AES Decrypt Error", err)
	}
	fmt.Println("json Decrypt=", jsonStr)

	err = json.Unmarshal([]byte(jsonStr), &ParamData)
	if err != nil {
		fmt.Fprintf(w, paramError) //output to client with w
		return
	}
	delete(ParamData, "param")
	fmt.Println("json Unmarshal=", ParamData, "\n")

	userName := ParamData["UserName"]
	certId := ParamData["CertID"]
	hardId := ParamData["HardID"]
	respJson := amCertCtrl.AmCertNewLicence(userName, certId, hardId)

	fmt.Fprintf(w, respJson) //output to client with w
}
