package serves

import (
	//	"fmt"
	"net/http"
	"strings"
)

func BSParseForm(w http.ResponseWriter, r *http.Request) map[string]string {
	r.ParseForm() // 解析参数,默认是不会解析的

	var paramData map[string]string = make(map[string]string, 1)
	for k, v := range r.Form {
		paramData[k] = strings.Join(v, "")
		//		fmt.Println("key:", k)
		//		fmt.Println("val:", strings.Join(v, ""))
	}

	//	fmt.Println("r.form", r.Form)
	//	fmt.Println("path", r.URL.Path)
	//	fmt.Println("scheme", r.URL.Scheme)
	//	fmt.Println("url_long", r.Form["url_long"])

	return paramData
}
