// uuid is a lightweight UUID implementation
package uuid
