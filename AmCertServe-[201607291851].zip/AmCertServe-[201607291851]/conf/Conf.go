//setting config information
package conf

type ConfWeb struct {
	Host string
	Port string
	Path string
}

type ConfDb struct {
	Type string // db type
	User string // user name
	Psw  string // user password
	Host string // db host address
	Port string // db port
	Name string // db name
}

var (
	Cweb *ConfWeb
	Cdb  *ConfDb
)

func init() {
	Cweb = &ConfWeb{"http://192.168.100.100", "9090", ""}
	Cdb = &ConfDb{"mongodb", "root", "123456", "192.168.100.100", "8080", "cloudplatform"}
}

func CwebBaseURL() string {
	return Cweb.Host + Cweb.Port + Cweb.Path
}

func CdbBaseURL() string {
	if Cdb.Type == "mongodb" {
		return Cdb.Type + "://" + Cdb.User + ":" + Cdb.Psw + "@" + Cdb.Host + ":" + Cdb.Port + "/" + Cdb.Name
		//mgoURL = "mongodb://mgoUser:mgoPsw@127.0.0.1:10001/mgodb
	}
	return Cdb.User + ":" + Cdb.Psw + "@tcp(" + Cdb.Host + ":" + Cdb.Port + ")/" + Cdb.Name + "?charset=utf8"
	//mysqlURL = root:123456@tcp(192.168.100.118:3306)/mysqlDb?charset=utf8
}
