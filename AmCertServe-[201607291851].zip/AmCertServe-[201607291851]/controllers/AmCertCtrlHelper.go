package controllers

import (
	"AmCertServe/libs/Crypto"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strconv"
)

//Request Return Info
type RespInfo struct {
	ErrorNo   string //1000:操作成功； 1001：数据库操作失败； 1002：输入参数不合法； 1003：其他错误
	ErrorInfo string
	Result    string
}

var AesKey string = "authen_cbsr.1210"

/**********************************************************/
// AES-128 encrypt, then base64 encode. key长度：16, 24, 32 bytes 对应 AES-128, AES-192, AES-256
func Base64AesEnResult(orig []byte, key []byte) (string, error) {
	fmt.Println("Before Aes En: " + string(orig))
	aesresult, err := lcrypto.AesEncrypt([]byte(orig), key)
	if err != nil {
		//	panic(err)
		return "null", err
	}
	respDes := base64.StdEncoding.EncodeToString(aesresult)
	return respDes, nil
}

// base64 decode, then AES-128 decrypt. key长度：16, 24, 32 bytes 对应 AES-128, AES-192, AES-256
func Base64AesDeResult(crypted string, key []byte) (string, error) {
	fmt.Println("Before Aes De: " + crypted)
	origAes, err := base64.StdEncoding.DecodeString(crypted)
	if err != nil {
		return "null", err
	}

	origStr, err := lcrypto.AesDecrypt(origAes, key)
	if err != nil {
		return "null", err
	}

	return string(origStr), nil
}

// base64 encoding result of DES
func Base64EncodeDesResult(orig []byte, key []byte) (string, error) {
	fmt.Println("Before Des: " + string(orig))
	desresult, err := lcrypto.DesEncrypt([]byte(orig), key)
	if err != nil {
		return "null", err
	}
	respDes := base64.StdEncoding.EncodeToString(desresult)
	fmt.Println(respDes)
	return respDes, nil
}

func GenerateJsonWithResult(info *RespInfo) string {
	if _, err := json.Marshal(info); err != nil {
		info.ErrorNo = "1003"
		info.ErrorInfo = "其他错误"
		info.Result = "null"
		return ""
	}

	respJson, _ := json.Marshal(info)

	return string(respJson)
}

//error==nil:参数转换成功，返回int值为转换结果，有用
//error！=nil：参数转换失败，返回int值无用
func CheckIntParameter(info *RespInfo, param string) (int64, error) {
	var (
		subIndex int64
		subErr   error
	)
	if subIndex, subErr = strconv.ParseInt(param, 10, 0); subErr != nil {
		info.ErrorNo = "1002"
		info.ErrorInfo = "输入参数不合理"
		info.Result = "null"
	}
	return subIndex, subErr
}
