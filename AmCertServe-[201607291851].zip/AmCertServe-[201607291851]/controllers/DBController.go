package controllers

import (
	"AmCertServe/daos"
	"AmCertServe/libs/orm"
	"AmCertServe/models"
	"encoding/json"
	"fmt"
	"strings"
)

const newLicKey string = "Avaliable"
const newLicErr string = "Info"

var (
	baseDao *daos.DbOrm
	bindDao *daos.BindDao
	userDao *daos.UserDao
	certDao *daos.CertDao
)

type DBController struct {
}

func init() {
	baseDao = new(daos.DbOrm)
	bindDao = new(daos.BindDao)
	userDao = new(daos.UserDao)
	certDao = new(daos.CertDao)
}

//Query certification list by company_id
//return string : query result(certListJson {CertID, ExpireDate, TotalBindCount, UsedBindCount}) with json

func (this *DBController) DbCertListOrmQuery(amComName string, amPassword string) (string, int) {

	dbOrm := baseDao.NewOrm()

	var maps []orm.Params
	//check user exist or not, if exist return "Password" & "Salt"
	maps, errNo := userDao.QueryInfoByName(dbOrm, amComName)
	if errNo != 0 { //error = 100-数据库连接失败; 1-用户不存在
		return "null", errNo
	}

	//check password
	dbPsw := maps[0]["Password"].(string)
	salt := maps[0]["Salt"].(string)
	pswCorrect, _ := userDao.CheckPasswordbySalt(amPassword, dbPsw, salt)
	if pswCorrect == false { //error = 2-密码错误
		return "null", 2
	}
	delete(maps[0], "Password")
	delete(maps[0], "Salt")

	maps, errNo = certDao.QueryListByComName(dbOrm, amComName)
	if errNo != 0 { //error = 100-数据库连接失败
		return "null", errNo
	}

	//replace product_code with product_name
	for _, val := range maps {
		for subKey, subVal := range val {
			if strings.EqualFold(subKey, "ProductCode") {
				subVal = models.Product_GetNameByCode(subVal.(string))
				val[subKey] = subVal
			}
		}
	}

	mapsJson, err := json.Marshal(maps)
	if err != nil {
		errNo = 101 //系统错误
	} else {
		errNo = 0 //操作正常
	}
	return string(mapsJson), errNo
}

//Query new licence can be created or not
//return string : query result with json
func (this *DBController) DbCertUsageQuery(amUsrName string, amCertID string, amHardID string) int {

	dbOrm := baseDao.NewOrm()

	//检查当前证书有没有授权权限

	//检查证书和机器是否已经绑定
	binded, errNo := bindDao.CheckCertMachineBinding(dbOrm, amCertID, amHardID)
	if errNo != 0 {
		return errNo
	}
	if binded {
		return 0
	}

	//检查证书是否可用
	_, errNo = certDao.IsCertAvaliableWithID(dbOrm, amCertID)
	if errNo != 0 {
		return errNo
	}

	//插入绑定数据
	_, errNo = bindDao.InsertNewBind(dbOrm, amCertID, amHardID, amUsrName)
	if errNo != 0 {
		return errNo
	}

	//更新cert表
	_, errNo = certDao.UpdateUsedCountByID(dbOrm, amCertID)
	if errNo != 0 {
		return errNo
	}

	return 0
}
