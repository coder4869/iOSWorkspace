package controllers

import (
	"fmt"
	"strconv"
)

type AmCertCtrl struct {
}

//query cert list, return certListJson {certID, expDate, totalBindCount, leftBindCount}
//return query result
/*
ErrorNo-ErrorInfo-Result
0-操作成功-Base64（AES）
1-用户不存在-null
2-密码错误-null
100-数据库连接失败-null
101-系统错误-null
*/
func (this *AmCertCtrl) AmCertList(amComName string, amPassword string) string {

	var respInfo *RespInfo = new(RespInfo)
	var dbCtrl *DBController = new(DBController)
	listJson, errNo := dbCtrl.DbCertListOrmQuery(amComName, amPassword)

	respInfo.ErrorNo = strconv.Itoa(errNo)
	respInfo.Result = "null"

	switch errNo {
	case 0: //0-操作成功
		respInfo.ErrorInfo = "操作成功"
		if respDes, err := Base64AesEnResult([]byte(listJson), []byte(AesKey)); err == nil {
			respInfo.Result = respDes
		} else {
			respInfo.ErrorNo = "101"
			respInfo.ErrorInfo = "系统错误"
			fmt.Printf("list query error 101%v\n", err)
		}
		break
	case 1:
		respInfo.ErrorInfo = "用户不存在"
		break
	case 2:
		respInfo.ErrorInfo = "密码错误"
		break
	case 100:
		respInfo.ErrorInfo = "数据库连接失败"
		break
	case 101:
		respInfo.ErrorInfo = "系统错误"
		break
	default:
		break
	}

	return GenerateJsonWithResult(respInfo)
}

//check new licence avaliable or not, return json {"cmd":"cmd_no", "error":"error_info"}
//return check result
/*
ErrorNo-ErrorInfo-Result
0-操作成功/已绑定-null
1-参数错误-null
2-没有可用证书-null
3-已绑定-null //ignore
4-绑定失败-null
100-数据库连接失败-null
101-系统错误-null
*/
func (this *AmCertCtrl) AmCertNewLicence(userName string, certId string, hardId string) string {

	var respInfo *RespInfo = new(RespInfo)
	var dbCtrl *DBController = new(DBController)

	errNo := dbCtrl.DbCertUsageQuery(userName, certId, hardId)

	respInfo.ErrorNo = strconv.Itoa(errNo)
	respInfo.Result = "null"

	switch errNo {
	case 0: //0-操作成功
		respInfo.ErrorInfo = "操作成功"
		break
	case 1:
		respInfo.ErrorInfo = "参数错误"
		break
	case 2:
		respInfo.ErrorInfo = "证书不存在"
		break
	case 3:
		respInfo.ErrorInfo = "证书已绑定"
		break
	case 4:
		respInfo.ErrorInfo = "绑定失败"
		break
	case 100:
		respInfo.ErrorInfo = "数据库连接失败"
		break
	case 101:
		respInfo.ErrorInfo = "系统错误"
		break
	default:
		break
	}

	return GenerateJsonWithResult(respInfo)
}
