package daos

import (
	"AmCertServe/libs/orm"
	"encoding/hex"
	"fmt"
	"strconv"
)

type UserDao struct {
}

func (this *UserDao) QueryIDByName(o orm.Ormer, amUsrName string) (string, int) {
	var maps []orm.Params
	// get salt
	selectSql := "select usr.id as UserID "
	fromSql := "from T_cus_user as usr "
	whereSql := "where usr.user_name=?"

	if _, err := o.Raw(selectSql+fromSql+whereSql, amUsrName).Values(&maps); err != nil {
		fmt.Printf("User ID Query Error Info:%v\n", err)
		return "", 100 //ErrorNo=100, 数据库连接失败
	}
	return maps[0]["UserID"].(string), 0 //操作正常
}

func (this *UserDao) QueryInfoByName(o orm.Ormer, amUsrName string) ([]orm.Params, int) {
	var maps []orm.Params
	// get salt
	selectSql := "select usr.password as Password, usr.salt as Salt, count(usr.id) as IsUserExist "
	fromSql := "from T_cus_user as usr "
	whereSql := "where usr.user_name=?"

	if _, err := o.Raw(selectSql+fromSql+whereSql, amUsrName).Values(&maps); err != nil {
		fmt.Printf("User Info Query Error Info:%v\n", err)
		return nil, 100 //ErrorNo=100, 数据库连接失败
	}

	//user not exist
	if userExist, _ := strconv.ParseInt(maps[0]["IsUserExist"].(string), 10, 0); userExist == 0 {
		return nil, 1 //ErrorNo=1, 用户不存在
	}

	delete(maps[0], "IsUserExist")

	return maps, 0 //操作正常
}

func (this *UserDao) CheckPasswordbySalt(clientPsw string, dbPsw string, salt string) (bool, int) {

	cPswByte, _ := hex.DecodeString(clientPsw)
	saltByte, _ := hex.DecodeString(salt)

	fmt.Printf("CPsw=%v\tBytes=%3v\n", clientPsw, cPswByte)
	fmt.Printf("Salt=%v\tBytes=%3v\n", salt, saltByte)

	for i := 0; i < 16; i++ {
		cPswByte[i] = cPswByte[i] ^ saltByte[i]
	}
	clientPsw = hex.EncodeToString(cPswByte)

	if dbPsw != clientPsw {
		return false, 2 //ErrorNo=2, 密码错误
	}
	return true, 0
}
