package daos

import (
	_ "AmCertServe/libs/mysql"
	"AmCertServe/libs/orm"
)

type DbOrm struct {
}

func init() {
	//register db driver
	orm.RegisterDriver("mysql", orm.DRMySQL) //orm.DRSqlite, orm.DRPostgres

	// set remote database
	// dev - platformdev : authendev / cloudplatform
	// test- platformtest: authentest/ platform_test
	// pro - platform_pro
	orm.RegisterDataBase("default", "mysql", "platformtest:authentest@tcp(192.168.101.217:3306)/platform_test?charset=utf8", 30)
	// set local database
	//	orm.RegisterDataBase("default", "mysql", "db_username:db_password@/db_name?charset=utf8")

	//  create table
	//	orm.RunSyncdb("default", force, verbose) //force:不强制建数据库(true/false); verbose:打印建表过程(true/false)
	orm.SetMaxIdleConns("default", 30) //设置数据库最大空闲连接
	orm.SetMaxOpenConns("default", 30) //设置数据库最大连接数

	orm.Debug = true // open ORM debug mode
}

func (this *DbOrm) NewOrm() orm.Ormer {

	o := orm.NewOrm()
	o.Using("cloudplatform") //set database

	return o
}
