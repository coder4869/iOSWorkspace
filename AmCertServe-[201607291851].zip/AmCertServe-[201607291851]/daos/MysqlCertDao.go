package daos

import (
	"AmCertServe/libs/orm"
	"fmt"
	"strconv"
)

type CertDao struct {
}

func (this *CertDao) QueryListByComName(o orm.Ormer, amComName string) ([]orm.Params, int) {
	var maps []orm.Params

	var selectSql string = "select cert.id as CertID, unix_timestamp(date(cert.start_time)) as StartDate, unix_timestamp(date(cert.end_time)) as ExpireDate, cert.apply_count as TotalBindCount "
	selectSql += ", cert.used_count as UsedBindCount, cert.platform_type as PlatformType, cert.product_code as ProductCode "
	fmt.Println(selectSql)
	var fromSql string = "from T_cus_certification as cert "
	var otherSql string = "where cert.cert_status=1 AND cert.cert_owner=(select usr.id from t_cus_user as usr where usr.user_name=?)"
	//	var otherSql string = "where cert.cert_status=1 AND cert.apply_count > cert.used_count AND cert.end_time>now() AND cert.cert_owner=(select usr.id from t_cus_user as usr where usr.user_name=?)"

	if _, err := o.Raw(selectSql+fromSql+otherSql, amComName).Values(&maps); err != nil {
		fmt.Printf("Cert List Query Error Info:%v\n", err)
		return nil, 100 //ErrorNo=100, 数据库连接失败
	}
	//	fmt.Printf("maps%v\n", maps)

	return maps, 0
}

func (this *CertDao) IsCertAvaliableWithID(o orm.Ormer, amCertID string) (bool, int) {
	var maps []orm.Params

	//query TotalBindCount
	selectSql := "select count(cert.id) as IsCertExist, cert.apply_count as TotalBindCount, cert.used_count as UsedBindCount "
	fromSql := "from T_cus_certification as cert "
	otherSql := "where cert.id=?"

	if _, err := o.Raw(selectSql+fromSql+otherSql, amCertID).Values(&maps); err != nil {
		fmt.Printf("Cert With ID Query Error Info:%v\n", err)
		return false, 100 //ErrorNo=100, 数据库连接失败
	}

	IsCertExist, _ := strconv.ParseInt(maps[0]["IsCertExist"].(string), 10, 0)
	if IsCertExist == 0 {
		return false, 2 //ErrorNo=2, 没有可用证书
	}

	return true, 0 //操作正常
}

func (this *CertDao) UpdateUsedCountByID(o orm.Ormer, amCertID string) (bool, int) {

	updateSql := "update T_cus_certification as cert "
	setSql := "set cert.used_count=cert.used_count+1 "
	whereSql := "where cert.id=?"

	index, err := o.Raw(updateSql+setSql+whereSql, amCertID).Exec()
	if err != nil {
		fmt.Printf("Cert With ID Update Error Info:%v\n", err)
		return false, 100 //ErrorNo=100, 数据库连接失败
	}
	row, _ := index.LastInsertId()
	fmt.Printf("Cert Update Line:%d\n", row)
	return true, 0 //操作正常
}
