package daos

import (
	"AmCertServe/libs/orm"
	"AmCertServe/libs/uuid"
	"fmt"
	"strconv"
	"strings"

	"time"
)

type BindDao struct {
}

//query CertId-HardwareId binding exist or not
func (this *BindDao) CheckCertMachineBinding(o orm.Ormer, amCertID string, amMachineCode string) (bool, int) {
	var maps []orm.Params

	selectSql := "select count(bind.cert_id) as IsBinded "
	fromSql := "from T_cus_certification_binding as bind "
	otherSql := "where bind.cert_id=? AND bind.machine_code=?"

	if _, err := o.Raw(selectSql+fromSql+otherSql, amCertID, amMachineCode).Values(&maps); err != nil {
		fmt.Printf("Cert Machine Bind Query Error Info:%v\n", err)
		return false, 100 //数据库连接失败
	}

	if usedBind, _ := strconv.ParseInt(maps[0]["IsBinded"].(string), 10, 0); usedBind != 0 {
		return true, 0 //机器和证书已经绑定
	}

	return false, 0 //尚未绑定，操作正常
}

func (this *BindDao) InsertNewBind(o orm.Ormer, amCertID string, amMachineCode string, amUserName string) (bool, int) {

	insertSql := "insert into T_cus_certification_binding(id,cert_id, machine_code, create_by, create_time, modify_by, modify_time, remark) "
	insertVal := "values(?,+?,?,?,?,\"\",?,\"\")"
	insertId := strings.Replace(uuid.Rand().Hex(), "-", "", -1)
	timeStr := time.Now().Format("2006-01-02 15:04:05") //fixd

	var userDao *UserDao = new(UserDao)
	userID, errNo := userDao.QueryIDByName(o, amUserName)
	if errNo != 0 {
		return false, errNo
	}

	index, err := o.Raw(insertSql+insertVal, insertId, amCertID, amMachineCode, userID, timeStr, timeStr).Exec()
	if err != nil {
		return false, 100 //数据库连接失败
	}
	row, _ := index.LastInsertId()
	fmt.Printf("Bind Insert Line:%d\n", row)
	return false, 0 //尚未绑定，操作正常
}
